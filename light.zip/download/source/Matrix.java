//=============================================================================
// Class:       Matrix
//
// Desc:        4x4 matrix representing homogeneous transformations.
//              All matrices are row-major, all transformations are expressed
//              using left-handed convention and all vector/matrix xformations
//              follow the operator_on_leftist convention. That means that in
//              order to transform vector by matrix you need to multiply
//              row vector on the left by matrix on the right (v' = vM).
//              That also means that translation vector resides in last row
//              of 4x4 matrix and projection info -- in the last column.
//              Each row of upper 3x3 submatrix contain images of axes after
//              transformation.
//              ie the axes of coordinate system represented by the matrix.
//              We use left-handed convention, so row 0 contains right vector
//              (X axis), row 1 - up vector (Y axis) and row 2 - DOF vector
//              (Z axis).
//
// See Also:    Vec3/Vec4 notes about aliasing! [I mean it! ;-)]
//=============================================================================
public final class Matrix
{
    // Predefined matrices -- can be used both as handles (constant!)
    // and for copy ctor/set method (*strongly* preferred)
    // BE CAREFUL! DO NOT MODIFY THESE MATRICES.

    public static final Matrix IDENTITY =
        new Matrix( 1, 0, 0, 0,
                    0, 1, 0, 0,
                    0, 0, 1, 0,
                    0, 0, 0, 1);

    public static final Matrix ZERO =
        new Matrix( 0, 0, 0, 0,
                    0, 0, 0, 0,
                    0, 0, 0, 0,
                    0, 0, 0, 0);

    // Default ctor, does nothing
    Matrix()
    {
        // Do nothing...
    }

    // Constructor -- initializes matrix with given 16 values (row-major!)
    Matrix( float m00, float m01, float m02, float m03,
            float m10, float m11, float m12, float m13,
            float m20, float m21, float m22, float m23,
            float m30, float m31, float m32, float m33)
    {
        set(
            m00, m01, m02, m03,
            m10, m11, m12, m13,
            m20, m21, m22, m23,
            m30, m31, m32, m33);
    }

    // Constructs a new matrix with the same values as given one.
    Matrix(final Matrix m)
    {
        set(m);
    }

    // Sets this matrix to identity
    public final void setIdentity()
    {
        m00 = 1; m01 = 0; m02 = 0; m03 = 0;
        m10 = 0; m11 = 1; m12 = 0; m13 = 0;
        m20 = 0; m21 = 0; m22 = 1; m23 = 0;
        m30 = 0; m31 = 0; m32 = 0; m33 = 0;
    }

    // Sets this matrix to zero
    public final void setZero()
    {
        m00 = 0; m01 = 0; m02 = 0; m03 = 0;
        m10 = 0; m11 = 0; m12 = 0; m13 = 0;
        m20 = 0; m21 = 0; m22 = 0; m23 = 0;
        m30 = 0; m31 = 0; m32 = 0; m33 = 0;
    }

    // Sets all elements of matrix
    public final void set(
                        float m00, float m01, float m02, float m03,
                        float m10, float m11, float m12, float m13,
                        float m20, float m21, float m22, float m23,
                        float m30, float m31, float m32, float m33)
    {
        this.m00 = m00; this.m01 = m01; this.m02 = m02; this.m03 = m03;
        this.m10 = m10; this.m11 = m11; this.m12 = m12; this.m13 = m13;
        this.m20 = m20; this.m21 = m21; this.m22 = m22; this.m23 = m23;
        this.m30 = m30; this.m31 = m31; this.m32 = m32; this.m33 = m33;
    }

    // Sets this matrix to be an exact copy of matrix 'm'
    public final void set(final Matrix m)
    {
        m00 = m.m00; m01 = m.m01; m02 = m.m02; m03 = m.m03;
        m10 = m.m10; m11 = m.m11; m12 = m.m12; m13 = m.m13;
        m20 = m.m20; m21 = m.m21; m22 = m.m22; m23 = m.m23;
        m30 = m.m30; m31 = m.m31; m32 = m.m32; m33 = m.m33;
    }

    public final void setRight(final Vec3 v)
    {
        m00 = v.x; m01 = v.y; m02 = v.z;
    }

    public final void setUp(final Vec3 v)
    {
        m10 = v.x; m11 = v.y; m12 = v.z;
    }

    public final void setDOF(final Vec3 v)
    {
        m20 = v.x; m21 = v.y; m22 = v.z;
    }

    public final void setTranslation(final Vec3 v)
    {
        m30 = v.x; m31 = v.y; m32 = v.z;
    }

    // self = m * self
    public final void preMul(final Matrix m)
    {
        set(
            m.m00*m00 + m.m01*m10 + m.m02*m20 + m.m03*m30,
            m.m00*m01 + m.m01*m11 + m.m02*m21 + m.m03*m31,
            m.m00*m02 + m.m01*m12 + m.m02*m22 + m.m03*m32,
            m.m00*m03 + m.m01*m13 + m.m02*m23 + m.m03*m33,

            m.m10*m00 + m.m11*m10 + m.m12*m20 + m.m13*m30,
            m.m10*m01 + m.m11*m11 + m.m12*m21 + m.m13*m31,
            m.m10*m02 + m.m11*m12 + m.m12*m22 + m.m13*m32,
            m.m10*m03 + m.m11*m13 + m.m12*m23 + m.m13*m33,

            m.m20*m00 + m.m21*m10 + m.m22*m20 + m.m23*m30,
            m.m20*m01 + m.m21*m11 + m.m22*m21 + m.m23*m31,
            m.m20*m02 + m.m21*m12 + m.m22*m22 + m.m23*m32,
            m.m20*m03 + m.m21*m13 + m.m22*m23 + m.m23*m33,

            m.m30*m00 + m.m31*m10 + m.m32*m20 + m.m33*m30,
            m.m30*m01 + m.m31*m11 + m.m32*m21 + m.m33*m31,
            m.m30*m02 + m.m31*m12 + m.m32*m22 + m.m33*m32,
            m.m30*m03 + m.m31*m13 + m.m32*m23 + m.m33*m33
           );
    }

    // self = self * m
    public final void postMul(final Matrix m)
    {
       set(
           m00*m.m00 + m01*m.m10 + m02*m.m20 + m03*m.m30,
           m00*m.m01 + m01*m.m11 + m02*m.m21 + m03*m.m31,
           m00*m.m02 + m01*m.m12 + m02*m.m22 + m03*m.m32,
           m00*m.m03 + m01*m.m13 + m02*m.m23 + m03*m.m33,

           m10*m.m00 + m11*m.m10 + m12*m.m20 + m13*m.m30,
           m10*m.m01 + m11*m.m11 + m12*m.m21 + m13*m.m31,
           m10*m.m02 + m11*m.m12 + m12*m.m22 + m13*m.m32,
           m10*m.m03 + m11*m.m13 + m12*m.m23 + m13*m.m33,

           m20*m.m00 + m21*m.m10 + m22*m.m20 + m23*m.m30,
           m20*m.m01 + m21*m.m11 + m22*m.m21 + m23*m.m31,
           m20*m.m02 + m21*m.m12 + m22*m.m22 + m23*m.m32,
           m20*m.m03 + m21*m.m13 + m22*m.m23 + m23*m.m33,

           m30*m.m00 + m31*m.m10 + m32*m.m20 + m33*m.m30,
           m30*m.m01 + m31*m.m11 + m32*m.m21 + m33*m.m31,
           m30*m.m02 + m31*m.m12 + m32*m.m22 + m33*m.m32,
           m30*m.m03 + m31*m.m13 + m32*m.m23 + m33*m.m33
          );
    }

    // self = m1 * m2
    public final void mul(final Matrix m1, final Matrix m2)
    {
        m00 = m1.m00*m2.m00+m1.m01*m2.m10+m1.m02*m2.m20+m1.m03*m2.m30;
        m01 = m1.m00*m2.m01+m1.m01*m2.m11+m1.m02*m2.m21+m1.m03*m2.m31;
        m02 = m1.m00*m2.m02+m1.m01*m2.m12+m1.m02*m2.m22+m1.m03*m2.m32;
        m03 = m1.m00*m2.m03+m1.m01*m2.m13+m1.m02*m2.m23+m1.m03*m2.m33;

        m10 = m1.m10*m2.m00+m1.m11*m2.m10+m1.m12*m2.m20+m1.m13*m2.m30;
        m11 = m1.m10*m2.m01+m1.m11*m2.m11+m1.m12*m2.m21+m1.m13*m2.m31;
        m12 = m1.m10*m2.m02+m1.m11*m2.m12+m1.m12*m2.m22+m1.m13*m2.m32;
        m13 = m1.m10*m2.m03+m1.m11*m2.m13+m1.m12*m2.m23+m1.m13*m2.m33;

        m20 = m1.m20*m2.m00+m1.m21*m2.m10+m1.m22*m2.m20+m1.m23*m2.m30;
        m21 = m1.m20*m2.m01+m1.m21*m2.m11+m1.m22*m2.m21+m1.m23*m2.m31;
        m22 = m1.m20*m2.m02+m1.m21*m2.m12+m1.m22*m2.m22+m1.m23*m2.m32;
        m23 = m1.m20*m2.m03+m1.m21*m2.m13+m1.m22*m2.m23+m1.m23*m2.m33;

        m30 = m1.m30*m2.m00+m1.m31*m2.m10+m1.m32*m2.m20+m1.m33*m2.m30;
        m31 = m1.m30*m2.m01+m1.m31*m2.m11+m1.m32*m2.m21+m1.m33*m2.m31;
        m32 = m1.m30*m2.m02+m1.m31*m2.m12+m1.m32*m2.m22+m1.m33*m2.m32;
        m33 = m1.m30*m2.m03+m1.m31*m2.m13+m1.m32*m2.m23+m1.m33*m2.m33;
    }

    // Inverts this matrix in place, assumes that matrix only contains
    // affine transformations (NO projection stuff!), returns ref to
    // itself
    public final Matrix invertAffine()
    {
        // Transpose 3x3 submatrix (rotation/scaling)
        float temp;
        temp = m01; m01 = m10; m10 = temp;
        temp = m02; m02 = m20; m20 = temp;
        temp = m12; m12 = m21; m21 = temp;

        // Clear projection
        m03 = m13 = m23 = 0;
        m33 = 1;

        // Back-transform translation
        m30 = -(m30 * m00 + m31 * m10 + m32 * m20);
        m31 = -(m30 * m01 + m31 * m11 + m32 * m21);
        m32 = -(m30 * m02 + m31 * m12 + m32 * m22);

        return this;
    }

    // Sets this matrix to contain inverse of given matrix m.
    // Assumes that matrix m contains only affine transformations.
    // Returns ref to itself (inverted matrix)
    public final Matrix invertAffine(final Matrix m)
    {
        // Transpose 3x3 submatrix (rotation/scaling)
        m00 = m.m00; m01 = m.m10; m02 = m.m20;
        m10 = m.m01; m11 = m.m11; m12 = m.m21;
        m20 = m.m02; m21 = m.m12; m22 = m.m22;

        // Clear projection
        m03 = m13 = m23 = 0;
        m33 = 1;

        // Back-transform translation
        m30 = -(m.m30 * m00 + m.m31 * m10 + m.m32 * m20);
        m31 = -(m.m30 * m01 + m.m31 * m11 + m.m32 * m21);
        m32 = -(m.m30 * m02 + m.m31 * m12 + m.m32 * m22);

        return this;
    }

    public final void setRot(float angleDegs, float ax, float ay, float az)
    {
        // Normalize axis if needed
        float rlen = ax*ax + ay*ay + az*az;
        if (rlen != 1)
        {
           rlen = 1 / (float)Math.sqrt(rlen);
           ax = ax * rlen;
           ay = ay * rlen;
           az = az * rlen;
        }

        // Convert to quaternion
        final float angleRads = VecMath.degsToRads(angleDegs) * 0.5f;
        final float s = (float)Math.sin(angleRads);
        final float x = s * ax;
        final float y = s * ay;
        final float z = s * az;
        final float w = (float)Math.cos(angleRads);

        setFromQuat(x, y, z, w);
    }

    public final void setRot(float angleDegs, Vec3 axis)
    {
        setRot(angleDegs, axis.x, axis.y, axis.z);
    }

    // Sets this matrix to contain rotation represented by given
    // quaternion (x, y, z, w)
    //
    // For the present method takes 12 muls.
    public final void setFromQuat(float x, float y, float z, float w)
    {
        float xx = 2 * x;
        float yy = 2 * y;
        float zz = 2 * z;
        final float xxy = xx * y;
        final float xxz = xx * z;
        final float yyz = yy * z;
        final float xxw = xx * w;
        final float yyw = yy * w;
        final float zzw = zz * w;

        xx *= x;
        yy *= y;
        zz *= z;

        m00 = 1 - yy - zz;  m01 = xxy + zzw;    m02 = xxz - yyw;
        m10 = xxy - zzw;    m11 = 1 - yy - zz;  m12 = yyz + xxw;
        m20 = xxz + yyw;    m21 = yyz - xxw;    m22 = 1 - xx - yy;
    }

    // Sets this matrix to contain projection transformation.
    //
    // In:      fov - horizontal FOV (angular) in degrees
    //          aspect - height/width aspect ratio (400/200 viewport
    //                  has 0.5 aspect ratio)
    //          zNear - near clipping plane (distance, [0, zFar[)
    //          zFar - far clipping plane (distance, ]zNear, INF[)
    public final void setProjection(final float fov, final float aspect,
        final float zNear, final float zFar)
    {
        // tan(fovV)
        // --------- = aspect_ratio [so, tan(fovV) = aspect * tan(fovH)]
        // tan(fovH)
    
        final float tanFov = (float)Math.tan(VecMath.degsToRads(fov) * 0.5f);
        final float w = 1 / tanFov;
        final float h = 1 / (aspect * tanFov);  // (vertical FOV)
        final float q = zFar / (zFar - zNear);

        setZero();
        m00 = w;
        m11 = h;
        m22 = q;
        m23 = 1;
        m32 = -q * zNear;
        m33 = 1;
    }

    public final String toString()
    {
        // Trick with line seperator from 
        // Kenji Hiranabe (Eiwa System Management, Inc.)
	    String nl = System.getProperty("line.separator");
        return  "[" + nl + "  ["+m00+"\t"+m01+"\t"+m02+"\t"+m03+"]" + nl +
                "  ["+m10+"\t"+m11+"\t"+m12+"\t"+m13+"]" + nl +
                "  ["+m20+"\t"+m21+"\t"+m22+"\t"+m23+"]" + nl +
                "  ["+m30+"\t"+m31+"\t"+m32+"\t"+m33+"] ]";
    }

    //-------------------------------------------------------------------------
    // Member variables
    //-------------------------------------------------------------------------

    public float m00, m01, m02, m03;
    public float m10, m11, m12, m13;
    public float m20, m21, m22, m23;
    public float m30, m31, m32, m33;
}
//-----------------------------------------------------------------------------
