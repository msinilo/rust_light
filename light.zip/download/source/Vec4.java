//=============================================================================
// Class:       Vec3
//
// Desc:        4-D vector
//
// Desc:        Class representing 4-D vector (and point, because I don't have
//              separate class for points/vectors).
//              Note about aliasing: most functions (especially those that 
//              mimic operators) appear in two versions.
//              One is alias-safe and the other is not.
//              Examples:
//                  v.negate();     // negates v in place                
//                  v.negate(v1);   // negates v1, puts the result in v1 
//              So, use v.negate if you mean v.negate(v), because the second
//              version isn't alias-safe!
//              To put it in other words: alias-safe methods usually looks like
//              there's one argument missing, that's because 'this' is one of
//              the arguments.
//              Other examples
//                  v.transform(m);         // OK, v *= m
//                  v.transform(v1, m);     // OK, v = v1 * m
//                  v.transform(v, m);      // ERROR! Wrong result!
//              Some methods like add, sub etc will work anyway, but please
//              do not rely on this!
//=============================================================================
public final class Vec4
{
    // Default ctor - does nothing
    public Vec4()
    {
        // Do nothing
    }

    // Constructs vector from given coords
    public Vec4(final float x, final float y, final float z, final float w)
    {
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
    }

    // Copies rhs to this vector
    public Vec4(final Vec4 rhs)
    {
        x = rhs.x;
        y = rhs.y;
        z = rhs.z;
        w = rhs.w;
    }

    // Sets this vector to (x, y, z)
    public final void set(final float x, final float y, final float z,
        final float w)
    {
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
    }

    // Copies rhs to this vector
    public final void set(final Vec4 rhs)
    {
        x = rhs.x;
        y = rhs.y;
        z = rhs.z;
        w = rhs.w;
    }

    // self = -self
    public final void negate()
    {
        x = -x;
        y = -y;
        z = -z;
        w = -w;
    } 

    // self += rhs
    public final void add(final Vec4 rhs)
    {
        x += rhs.x;
        y += rhs.y;
        z += rhs.z;
        w += rhs.w;
    }

    // self -= rhs
    public final void sub(final Vec4 rhs)
    {
        x -= rhs.x;
        y -= rhs.y;
        z -= rhs.z;
        w -= rhs.w;
    }

    // self *= s
    public final void mul(final float s)
    {   
        x *= s;
        y *= s;
        z *= s;
        w *= s;
    }

    // self /= s
    public final void div(final float s)
    {
        final float r = 1 / s;
        x *= r;
        y *= r;
        z *= r;
        w *= r;
    }

    // self = -v
    public final void negate(final Vec4 v)
    {
        x = -v.x;
        y = -v.y;
        z = -v.z;
        w = -v.w;
    }

    // self = v1 + v2
    public final void add(final Vec4 v1, final Vec4 v2)
    {
        x = v1.x + v2.x;
        y = v1.y + v2.y;
        z = v1.z + v2.z;
        w = v1.w + v2.w;
    }

    // self = v1 - v2
    public final void sub(final Vec4 v1, final Vec4 v2)
    {
        x = v1.x - v2.x;
        y = v1.y - v2.y;
        z = v1.z - v2.z;   
        w = v1.w - v2.w;   
    }

    // self = a * v1 + b * v2
    public final void combine(final float a, final Vec4 v1,
        final float b, final Vec4 v2)
    {
        x = a * v1.x + b * v2.x;
        y = a * v1.y + b * v2.y;
        z = a * v1.z + b * v2.z;
        w = a * v1.w + b * v2.w;
    }

    // Returns (self == rhs)
    public final boolean equals(final Vec4 rhs)
    {
        return x == rhs.x && y == rhs.y && z == rhs.z && w == rhs.w;
    }

    // Returns this o rhs ('o' operator denotes dot product)
    public final float dot(final Vec4 rhs)
    {
        return x * rhs.x + y * rhs.y + z * rhs.z + w * rhs.w; 
    }

    // Returns length of vector
    public final float length()
    {
        return (float)Math.sqrt(x * x + y * y + z * z + w * w);
    }

    // Returns squared length of vector
    public final float lengthSquared()
    {
        return x * x + y * y + z * z + w * w;
    }

    // Normalizes this vector
    public final Vec4 normalize()
    {
        float l = x * x + y * y + z * z + w * w;  
        if (l != 0.0)
        {
            l = 1 / (float)Math.sqrt(l);
            x *= l;
            y *= l;
            z *= l;
            w *= l;
        }
        return this;
    }

    // Sets this vector to be the result of 4-D transformation of itself
    // by given matrix (m).
    //
    // v' = vM  
    public final void transform(final Matrix m)
    {
        final float tx = x * m.m00 + y * m.m10 + z * m.m20 + w * m.m30;
        final float ty = x * m.m01 + y * m.m11 + z * m.m21 + w * m.m31;
        final float tz = x * m.m02 + y * m.m12 + z * m.m22 + w * m.m32;
        w = x * m.m03 + y * m.m13 + z * m.m23 + w * m.m33;
        x = tx;
        y = ty;
        z = tz;
    }

    // Sets this vector to be the result of 4-D vector transformation of
    // given vector (v) by given matrix (m).
    // 
    // v' = vM  
    public final void transform(final Vec4 v, final Matrix m)
    {
        x = v.x * m.m00 + v.y * m.m10 + v.z * m.m20 + v.w * m.m30;
        y = v.x * m.m01 + v.y * m.m11 + v.z * m.m21 + v.w * m.m31;
        z = v.x * m.m02 + v.y * m.m12 + v.z * m.m22 + v.w * m.m32;
        w = v.x * m.m03 + v.y * m.m13 + v.z * m.m23 + v.w * m.m33;
    }

    // Sets this vector to be the result of transformation of given
    // 3-D point (v) by matrix (m).
    //
    // Transformation assumes that 'w' coord of point == 1.
    //
    // v' = [vx vy vz 1] * M
    public final void transform(final Vec3 v, final Matrix m)
    {
        x = v.x * m.m00 + v.y * m.m10 + v.z * m.m20 + m.m30;
        y = v.x * m.m01 + v.y * m.m11 + v.z * m.m21 + m.m31;
        z = v.x * m.m02 + v.y * m.m12 + v.z * m.m22 + m.m32;
        w = v.x * m.m03 + v.y * m.m13 + v.z * m.m23 + m.m33;
    }

    public final String toString()
    {
        return "[" + x + "\t" + y + "\t" + z + "\t" + w + "]";
    }


    //-------------------------------------------------------------------------
    // Member variables
    //-------------------------------------------------------------------------

    public float x;
    public float y;
    public float z;
    public float w;
}
//-----------------------------------------------------------------------------
