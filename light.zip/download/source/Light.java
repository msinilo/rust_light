//<applet code=Light.class width=256 height=256>
//  <param name="OcclusionImage"    value="starlight1.jpg">
//  <param name="LightR"            value="20">
//  <param name="LightG"            value="63">
//  <param name="LightB"            value="127">
//  <param name="CameraDist"        value="1300">
//  <param name="PlaneDist"         value="100">
//  <param name="MultiColor"        value="0">
//  <param name="Blur"              value="1">
//</applet>

// _______
// CREDITS
//
// Coded by Maciej Sinilo (aka Yarpen/Substance) for CFXWeb JACC #2.
// (Java Applet Coding Contest).
//
// Questions, opinions --> msinilo@kki.net.pl
//
// _____
// NOTES
//
// I get something like 9 fps with 670 rays and blurring on my P5-200MMX 
// under standard JDK's AppletViewer. Should be a bit faster under 
// IE >= 5, I guess.
//
// ___________
// DESCRIPTION
//
// The idea behind this effect is really simple, telling the truth it
// consists of several smaller and larger hacks. 
// We have an occlusion image -- that's our mask that will block the rays of
// light. This image is converted to depth-buffer values (if pixel at given
// location is brighter than some threshold then we set depth-buffer value).
// 
// Light is just a bunch of rays with common origin. Generation of end-points
// for rays is taken almost as-is from Swop 64k intro by Proxium (they used
// it to generate galaxy of particles).
//
// The rest is very easy -- we just render the light. Each line is Z-buffered
// and anti-aliased (Wu anti-aliasing used). Line rasterizing routine is 
// broken, I think, but I don't care as long as the effect looks OK. 
// At the very end I blur final image in order to give it more soft and 
// smooth appearance (and to hide the bugs coming from line rasterizer :-).
//
// Source code is a bit bloated (all those Vec3/4, Matrix, Camera classes,
// but this way gives me total control over the light and depth-buffer,
// besides -- I am too lazy to kick out not needed stuff).
//
// Ideas? You may try to add another light (in other color of course) and
// mix it all together. Or, you can shade each ray (direction of ray would
// be its normal). I didn't do it because this is slow enough even now, but
// maybe you'll find a way to optimize it (which shouldn't be very hard :).
//
// Well, that's about it... Enjoy!
//


import java.applet.*;
import java.awt.*;
import java.awt.image.*;

//=============================================================================
public class Light extends Applet implements Runnable
{
    // 1/W is scaled a bit, in order to increase the precision of depth-buffer
    public static final float W_SCALER  = 4096.0f;

    public void init()
    {
        setBackground(Color.black);

        // Get dimensions of applet
        m_size = this.getSize();

        // Configuration (load from HTML code)
        configure();

        // Init back-buffer 
        m_backBuffer = new int[m_size.width * m_size.height];
        m_backBufferImg = createImage(
                    new MemoryImageSource(m_size.width, m_size.height, 
                            new DirectColorModel(24, 0xFF0000, 0x00FF00, 0xFF),
                            m_backBuffer, 0, m_size.width));

        // Occlusion & depth buffer
        m_occlusionBuffer = new int[m_size.width * m_size.height];

        Image img = getImage(getCodeBase(), m_imageName);
        MediaTracker tracker = new MediaTracker(this);
        tracker.addImage(img, 0);
        try
        {
            tracker.checkID(0, true);
            tracker.waitForID(0);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

        grabImage(img, m_occlusionBuffer, m_size.width, m_size.height);
        m_depthBuffer = new int[m_size.width * m_size.height];

        // Initialize rays
        // Config format is simple: 
        // Idx        Desc
        // ------------------------------------------------------------------
        //  0         number of "stages"
        //  1 + n*2   amount of point in n-th stage (n = 0,1,2,...,N)
        //  2 + n*2   radius (well, kinda) of n-th stage (n = 0,1,2,...,N)
        //
        // TODO:    Add possibility of configuring stages from the level of
        //          HTML code.
        int[] config = {    4,              // # stages
                            100, 350,       // Stage #0
                            140, 900,       // Stage #1
                            250, 1400,      // Stage #2 
                            180, 2250 };    // Stage #3
        m_rays = new Rays(m_lightColor, config, m_bMultiColor);  
    }

    public void start()
    {
        if (m_thread == null)
        {
            m_thread = new Thread(this);
            m_thread.setPriority(Thread.NORM_PRIORITY);
            m_thread.start();
        }
    }

    public void run()
    {
        // Configure line rasterize
        LineRasterizer lineRasterizer = new LineRasterizer();
        lineRasterizer.setRenderBuffer(m_backBuffer);
        lineRasterizer.setDepthBuffer(m_depthBuffer);

        Camera camera = new Camera();

        // Set camera position
        Matrix m = new Matrix(Matrix.IDENTITY);
        m.setTranslation(new Vec3(0, 0, -m_cameraDist));
        camera.setToWorldMatrix(m);

        float angle = 0;
        float xpos = 0;
        Vec3 lightPos = new Vec3(0, 0, 0);
        Vec3 lightRotAxis = new Vec3(1, 1, 0.0f);

        Matrix mr = new Matrix(Matrix.IDENTITY);
        mr.setTranslation(lightPos);
        mr.setRot(angle, lightRotAxis);
        m_rays.setToWorldMatrix(mr);

        Graphics gfx = this.getGraphics();

        final long startTime = System.currentTimeMillis();
        long curTime = 0;
        long lastTime = 0;
        int framesDrawn = 0;

        prepareDepthBuffer();

        int numRays = 0;
        final int maxRays = m_rays.getNumRays();

        // --- MAIN LOOP ---
        while (true)
        {
            curTime = System.currentTimeMillis();
            final float totalTime = curTime - startTime;

            if (curTime - lastTime >= 10000)     // Each 10 seconds
            {
                System.out.println("FPS: " + (float)framesDrawn / 10.0f);
                framesDrawn = 0;
                lastTime = curTime;
            }

            clear();
            m_rays.transformAndDraw(camera, lineRasterizer, numRays, xpos);
            if (m_bBlur)
                blur();

            flush(gfx);

            angle = (totalTime / 45.0f) % 360.0f;

//            lightPos.x = 1100.0f * (float)Math.sin(totalTime / 15000.0f);
// Uncomment to get simple Z scaling
//            lightPos.z = 60 * (float)Math.cos((curTime - startTime) / 2700.0f);
            mr.setRot(angle, lightRotAxis);
//            mr.setTranslation(lightPos);
            m_rays.setToWorldMatrix(mr);

            // THIS SUCKS. Hopefully won't run too strange on fast computers...
            // Translation is done in 2D to make it independent from the
            // camera parameters 
            xpos = 90 * (float)Math.sin(totalTime / 20000.0f);


            if (numRays < maxRays)
            {
                // acceleration!
                numRays += (int)(totalTime / 1900.0f);
                if (numRays > maxRays)
                    numRays = maxRays;
            }

            ++framesDrawn;

            try
            {
                Thread.sleep(10);
            }
            catch(InterruptedException e)
            {
                // Ignore...
            }
        }
    }

    public void stop()
    {
        if (m_thread != null && m_thread.isAlive())
        {
            m_thread.stop();
        }
        m_thread = null;
    }

    private final void clear()
    {
        for (int i = (m_size.width * m_size.height) - 1; i >= 0; --i)
            m_backBuffer[i] = 0;
    }

    private void blur()
    {
        final int w = m_size.width;
        final int h = m_size.height;

        for (int y = h - 2; y >= 1; --y)
            for (int x = w - 2; x >= 1; --x)
            {
                final int ofs = y * w + x;
//                m_backBuffer[ofs] = ((m_backBuffer[ofs - 1] >> 1) & 0x7F7F7F7F) +
//                                    ((m_backBuffer[ofs + 1] >> 1) & 0x7F7F7F7F);
                m_backBuffer[ofs] = ((m_backBuffer[ofs - 1] >> 2) & 0x3F3F3F3F) +
                                    ((m_backBuffer[ofs + 1] >> 2) & 0x3F3F3F3F) +
                                    ((m_backBuffer[ofs + w] >> 2) & 0x3F3F3F3F) +
                                    ((m_backBuffer[ofs - w] >> 2) & 0x3F3F3F3F);
            }
    }

    public final void update()
    {
    }

    public final void paint(Graphics gfx)
    {
    }

    private void flush(Graphics gfx)
    {
        m_backBufferImg.flush();
        if (gfx != null)
            gfx.drawImage(m_backBufferImg, 0, 0, null);
    }

    ///
    // Prepares depth buffer (if you don't write to it then it's enough to call
    // it only one time).
    // Algorithm is very simple: it scans occlusion image and:
    //  * if current pixel is lit then quite "near" value is written
    //    (for example, writing 1/700 would mean that the plane
    //    containing occluder lies 700 units from the camera). Only few rays
    //    will overwrite pixel at this location.
    //  * if current pixel is black then infinitely "far" value is written.
    //    That way every ray will easily overwrite this pixel
    //
    // Please note that each entry is in 16:16 fixed-point format (well, I use
    // only 1/W values, so most probably some 8:24 or 0:31 would be better...)
    private void prepareDepthBuffer()
    {
        // Calc plane dist in camera space (inverted)
        final float pdist = 1 / (float)(m_cameraDist - m_planeDist);

        for (int i = (m_size.width * m_size.height) - 1; i >= 0; --i)
        {
            final int pix = m_occlusionBuffer[i];
            final int crit = ((pix >> 16) & 0xFF) + ((pix >> 8) & 0xFF) + 
                (pix & 0xFF);

            if (crit > 0x3F)
                m_depthBuffer[i] = (int)(pdist * 65536.0f * W_SCALER);
            else                                            
                m_depthBuffer[i] = (int)0;
        }
    }

    private void configure()
    {
        // Occlusion image
        m_imageName = getParameter("OcclusionImage");

        // Light color
        final int lr = Integer.parseInt(getParameter("LightR"));
        final int lg = Integer.parseInt(getParameter("LightG"));
        final int lb = Integer.parseInt(getParameter("LightB"));
        m_lightColor = new Vec3(lr, lg, lb);

        // Camera distance
        m_cameraDist = Integer.parseInt(getParameter("CameraDist"));
        m_planeDist = Integer.parseInt(getParameter("PlaneDist"));

        m_bMultiColor = Integer.parseInt(getParameter("MultiColor")) != 0;
        m_bBlur= Integer.parseInt(getParameter("Blur")) != 0;
    }

    private void grabImage(Image img, int[] raw, int w, int h)
    {
        PixelGrabber pg = new PixelGrabber(img, 0, 0, w, h, raw, 0, w);
        try
        {
            pg.grabPixels();
        }
        catch(InterruptedException ignored)
        {
        }
    }

    //-------------------------------------------------------------------------
    // Member variables
    //-------------------------------------------------------------------------

    private Dimension       m_size = null;
    private Thread          m_thread = null;
    private Image           m_backBufferImg = null;
    private int[]           m_backBuffer = null;
    private int[]           m_occlusionBuffer = null;
    private int[]           m_depthBuffer = null;
    private Rays            m_rays;         
    
    private Vec3            m_lightColor = null;
    private String          m_imageName = null;
    private int             m_cameraDist = 900;
    private int             m_planeDist = 80;
    private boolean         m_bMultiColor;
    private boolean         m_bBlur;
}

//=============================================================================
// Class:       Rays
//=============================================================================
final class Rays
{
    // Constructs rays with given color and configuration.
    // If multi color is true than color is more like a pattern for RGB
    // components because sometimes they are swapped around in order to
    // make the rays multi-coloured.
    Rays(final Vec3 color, int[] rayConfig, boolean multiColor)
    {
        m_color = color;
        m_bMultiColor = multiColor;

        initRays(rayConfig);
    }

    public final void setToWorldMatrix(final Matrix m)
    {
        m_mtxToWorld.set(m);
    }

    public final int getNumRays()
    {
        return m_coords.length;
    }

    // Hope this gets inlined!!
    //
    // Returns true if point is inside view volume
    private static final boolean transform(Vec4 vout, final Vec3 v, 
        final Matrix m)
    {
        vout.transform(v, m);

        return  (vout.x > -vout.w && vout.x < vout.w) &&
                (vout.y > -vout.w && vout.y < vout.w) &&
                (vout.z > 0 && vout.z < vout.w);
    }

    // In:      numRays - # of rays to render
    //          transx2d - 2D translation of center (in X)
    //
    // Notes:   Method assumes 256x256 viewport!!!
    public final void transformAndDraw(final Camera cam,
        final LineRasterizer rasterizer, final int numRays,
        final float transx2d)
    {
        // Prepare transformation matrix from model to projection space
        cam.getToWorldMatrix(mtxWorldToCam);
        mtxWorldToCam.invertAffine();
        mtxWorldToCam.preMul(m_mtxToWorld);     // to world, then to camera space
        cam.getProjectionMatrix(mtxToProj);
        mtxToProj.preMul(mtxWorldToCam);        // model --> projection

        // Center point (return if not visible.. this is not very correct, but
        // I don't support clipping, so...)
        if (!transform(vtmp, m_center, mtxToProj))
            return;
        float coow = 1 / vtmp.w;
        // 126 (anti-aliasing!)
        float cx = 126.0f + (126.0f * vtmp.x * coow) + transx2d;
        if (cx > 252) cx = 252;
        else if (cx < 4) cx = 4;
        final float cy = 126.0f - (126.0f * vtmp.y * coow);
        // Scale 1/w
        coow *= Light.W_SCALER;
        
        int r = (int)(m_color.x);
        int g = (int)(m_color.y);
        int b = (int)(m_color.z);

        for (int i = 0; i < numRays; ++i)
        {
            if (!transform(vtmp, m_coords[i], mtxToProj))
                continue;

            final float oow = 1 / vtmp.w;
            // 126 (anti-aliasing!)
            float sx = 126.0f + (126.0f * vtmp.x * oow) + transx2d;
            if (sx > 252) sx = 252;
            else if (sx < 4) sx = 4;
            final float sy = 126.0f - (126.0f * vtmp.y * oow);

            if (m_bMultiColor)
            {
                final int d = (i % 4);
                int temp;
                if (d == 0)
                {
                    temp = r; r = g; g = temp;
                }   
                else if (d == 1)
                {
                    temp = b; b = g; g = temp;
                }
                else if (d == 2)
                {
                    temp = b; b = r; r = temp;
                }
            }

            rasterizer.Line(cx, cy, coow, sx, sy, oow * Light.W_SCALER, r, g, b);
        }
    }

    private void initRays(int[] config)
    {
        m_center = new Vec3(0, 0, 0);

        final int numStages = config[0];
        int numRays = 0;

        for (int s = 0; s < numStages; ++s)
            numRays += config[1 + s * 2];

        m_coords = new Vec3[numRays];
        int curRay = 0;

        // The following code (generating endpoints for the rays) is taken
        // almost as-is from sources of Swop 64k intro by Proxium 
        // (file !galaxy.h), should be available for download at any decent
        // scene server.
        for (int k = 0; k < numStages; ++k)
        {
            for (int i = 0; i < config[1 + k * 2]; ++i)
            {
                final float r = 
                    VecMath.unitRandom() * (float)config[2 + k * 2];
                final float phi = 
                    (VecMath.PI / 180) * VecMath.unitRandom() * 359;
                final float psi = 
                    (VecMath.PI / 180) * VecMath.unitRandom() * 359;

                m_coords[curRay] = new Vec3(
                                    r * (float)Math.cos(phi),
                                    r * (float)(Math.sin(phi) * Math.cos(psi)),
                                    r * (float)(Math.sin(phi) * Math.sin(psi)));

                m_center.add(m_coords[curRay]);
                ++curRay;
            }
        }

        // Calc center
        m_center.div((float)curRay);

        System.out.println("Generated " + curRay + " rays.");

        // Now translate all the points so that center lies at (0, 0, 0)
        // in local space.
        for (int p = 0; p < m_coords.length; ++p)
            m_coords[p].sub(m_center);

        m_center.set(0, 0, 0);
    }


    //-------------------------------------------------------------------------
    // Member variables
    //-------------------------------------------------------------------------

    Vec3    m_color = null;     // Light color, each component in [0, 255]
    Vec3    m_center = null;    // Rays center
    Vec3[]  m_coords = null;    // Ray coordinates
    Matrix  m_mtxToWorld = new Matrix(Matrix.IDENTITY);
    boolean m_bMultiColor = false;

    // --- Helpers, they are created here to avoid GC trashing our performance.
    Matrix mtxToProj = new Matrix();
    Matrix mtxWorldToCam = new Matrix();
    Vec4 vtmp = new Vec4();
}


//=============================================================================
// Class:       LineRasterizer
//=============================================================================
final class LineRasterizer
{
    public void setRenderBuffer(int[] buf)
    {
        m_scr = buf;
    }

    public void setDepthBuffer(int[] dbuf)
    {
        m_depthBuf = dbuf;
    }

    // Draws depth-buffered, Wu anti-aliased (with errors most probably) 
    // line from (x0, y0, z0) to (x1, y1, z1) with color (r, g, b)
    //
    // TODO:    Boost it a bit (e.g. -- kick those ceils(), find something
    //          faster)
    public void Line(   float x0, float y0, float z0,
                        float x1, float y1, float z1, int r, int g, int b)
    {
        
        float temp;

        // Calc deltas
        float deltaX = x1 - x0;
        float deltaY = y1 - y0;
        float deltaZ = z1 - z0;

        // Combine to base color
        final int color = (r << 16) | (g << 8) | b;

        if (VecMath.abs(deltaX) > VecMath.abs(deltaY))
        {
            // Swap coords if needed (delta always positive!)
            if (x0 > x1)
            {
                temp = x0; x0 = x1; x1 = temp;
                temp = y0; y0 = y1; y1 = temp;
                temp = z0; z0 = z1; z1 = temp;
                deltaX = -deltaX;
                deltaY = -deltaY;
                deltaZ = -deltaZ;
            }

            int ix0 = (int)Math.ceil(x0);

            // First pixel
            addPixel(ix0, (int)Math.ceil(y0), (int)(65536.0f * z0), color);

            // Calc line gradients (fixed points)
            final int gradY = (int)(65536.0f * deltaY / deltaX);
            final int gradZ = (int)(65536.0f * deltaZ / deltaX);

            final int prestep = (int)((Math.ceil(x0) - x0) * 65536.0f);
//            System.out.println("Ps: " + prestep * gradY);
            int y = (int)(y0 * 65536.0f) + ((prestep * gradY) >> 16);
            int z = (int)(z0 * 65536.0f) + ((prestep * gradZ) >> 16);

            int count = (int)Math.ceil(x1) - ix0 - 1;
            
            while (count-- > 0)
            {
                ++ix0;
                y += gradY;
                z += gradZ;

                // Calc brightness
                final int br2 = (y & 0xFFFF) >> 8;
                final int br1 = 256 - br2;
                final int r1 = (br1 * r) >> 8;
                final int g1 = (br1 * g) >> 8;
                final int b1 = (br1 * b) >> 8;
                final int r2 = (br2 * r) >> 8;
                final int g2 = (br2 * g) >> 8;
                final int b2 = (br2 * b) >> 8;

                final int iy = (y >> 16);
                addPixel(ix0, iy, z, (r1 << 16) | (g1 << 8) | b1);
                addPixel(ix0, iy + 1, z, (r2 << 16) | (g2 << 8) | b2);
            }

            // Final pixel
            addPixel((int)Math.ceil(x1), (int)Math.ceil(y1), 
                (int)(65536.0f * z1), color);
        }
        else    // major Y
        {
            // Swap coords if needed (delta always positive!)
            if (y0 > y1)
            {
                temp = x0; x0 = x1; x1 = temp;
                temp = y0; y0 = y1; y1 = temp;
                temp = z0; z0 = z1; z1 = temp;
                deltaX = -deltaX;
                deltaY = -deltaY;
                deltaZ = -deltaZ;
            }

            int iy0 = (int)Math.ceil(y0);
            //System.out.println(iy0);

            // First pixel
            addPixel((int)Math.ceil(x0), iy0, (int)(65536.0f * z0), color);

            // Calc line gradients (fixed points)
            final int gradX = (int)(65536.0f * deltaX / deltaY);
            final int gradZ = (int)(65536.0f * deltaZ / deltaY);

            final int prestep = (int)((Math.ceil(y0) - y0) * 65536.0f);
            int x = (int)(x0 * 65536.0f) + ((prestep * gradX) >> 16);
            int z = (int)(z0 * 65536.0f) + ((prestep * gradZ) >> 16);

            int count = (int)Math.ceil(y1) - iy0 - 1;
           
            while (count-- > 0)
            {
                x += gradX;
                ++iy0;
                z += gradZ;

                // Calc brightness
                final int br2 = (x & 0xFFFF) >> 8;
                final int br1 = 256 - br2;
                final int r1 = (br1 * r) >> 8;
                final int g1 = (br1 * g) >> 8;
                final int b1 = (br1 * b) >> 8;
                final int r2 = (br2 * r) >> 8;
                final int g2 = (br2 * g) >> 8;
                final int b2 = (br2 * b) >> 8;

                final int ix = (x >> 16);
                addPixel(ix, iy0, z, (r1 << 16) | (g1 << 8) | b1);
                addPixel(ix + 1, iy0, z, (r2 << 16) | (g2 << 8) | b2);
            }

            // Final pixel
            addPixel((int)Math.ceil(x1), (int)Math.ceil(y1), 
                (int)(65536.0f * z1), color);

        }
    
    }

    private final void addPixel(int x, int y, int z, int c)
    {
        // !!!
        // !!! WARNING! Hardcoded for width x 256 resolution ONLY
        // !!!
        final int ofs = x + (y << 8);

        // Please note that we don't write to depth-buffer!
        if (z > m_depthBuf[ofs])
        {
            final int pix = (c & 0xFEFEFEFF) + (m_scr[ofs] & 0xFEFEFEFF);
            int oflow = pix & 0x1010100;
            oflow = oflow - (oflow >> 8);
            m_scr[ofs] = 0xFF000000 | oflow | pix;
        }
    }

    int[]   m_scr;
    int[]   m_depthBuf;
}
//-----------------------------------------------------------------------------
