//=============================================================================
// Class:       Vec3
//
// Desc:        Class representing 3-D vector (and point, because I don't have
//              separate class for points/vectors).
//              Note about aliasing: most functions (especially those that 
//              mimic operators) appear in two versions.
//              One is alias-safe and the other is not.
//              Examples:
//                  v.negate();     // negates v in place                
//                  v.negate(v1);   // negates v1, puts the result in v1 
//              So, use v.negate if you mean v.negate(v), because the second
//              version isn't alias-safe!
//              To put it in other words: alias-safe methods usually looks like
//              there's one argument missing, that's because 'this' is one of
//              the arguments.
//              Other examples ('x' operator denots cross-product):
//                  v.cross(v1);        // OK, v x= v1
//                  v.cross(v1, v2);    // OK, v = v1 x v2
//                  v.cross(v, v1);     // ERROR! Wrong result!
//              Some methods like add, sub etc will work anyway, but please
//              do not rely on this!
//=============================================================================
public final class Vec3
{
    // Default ctor - does nothing
    public Vec3()
    {
        // Do nothing
    }

    // Constructs vector from given coords
    public Vec3(final float x, final float y, final float z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    // Copies rhs to this vector
    public Vec3(final Vec3 rhs)
    {
        x = rhs.x;
        y = rhs.y;
        z = rhs.z;
    }

    // Sets this vector to (x, y, z)
    public final void set(final float x, final float y, final float z)
    {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    // Copies rhs to this vector
    public final void set(final Vec3 rhs)
    {
        x = rhs.x;
        y = rhs.y;
        z = rhs.z;
    }

    // self = -self
    public final void negate()
    {
        x = -x;
        y = -y;
        z = -z;
    } 

    // self += rhs
    public final void add(final Vec3 rhs)
    {
        x += rhs.x;
        y += rhs.y;
        z += rhs.z;
    }

    // self -= rhs
    public final void sub(final Vec3 rhs)
    {
        x -= rhs.x;
        y -= rhs.y;
        z -= rhs.z;
    }

    // self *= s
    public final void mul(final float s)
    {   
        x *= s;
        y *= s;
        z *= s;
    }

    // self /= s
    public final void div(final float s)
    {
        final float r = 1 / s;
        x *= r;
        y *= r;
        z *= r;
    }

    // self = -v
    public final void negate(final Vec3 v)
    {
        x = -v.x;
        y = -v.y;
        z = -v.z;
    }

    // self = v1 + v2
    public final void add(final Vec3 v1, final Vec3 v2)
    {
        x = v1.x + v2.x;
        y = v1.y + v2.y;
        z = v1.z + v2.z;
    }

    // self = v1 - v2
    public final void sub(final Vec3 v1, final Vec3 v2)
    {
        x = v1.x - v2.x;
        y = v1.y - v2.y;
        z = v1.z - v2.z;   
    }

    // self = a * v1 + b * v2
    public final void combine(final float a, final Vec3 v1,
        final float b, final Vec3 v2)
    {
        x = a * v1.x + b * v2.x;
        y = a * v1.y + b * v2.y;
        z = a * v1.z + b * v2.z;
    }

    // Returns (self == rhs)
    public final boolean equals(final Vec3 rhs)
    {
        return x == rhs.x && y == rhs.y && z == rhs.z;
    }

    // self = self x v ('x' operator denotes cross product)
    public final void cross(final Vec3 v)
    {
        final float tx = y * v.z - z * v.y;
        final float ty = z * v.x - x * v.z;
        z = x * v.y - y * v.x;
        x = tx;
        y = ty;
    }

    // self = v1 x v2 ('x' operator denotes cross product)
    public final void cross(final Vec3 v1, final Vec3 v2)
    {
        x = v1.y * v2.z - v1.z * v2.y;
        y = v1.z * v2.x - v1.x * v2.z;
        z = v1.x * v2.y - v1.y * v2.x;
    }

    // Returns this o rhs ('o' operator denotes dot product)
    public final float dot(final Vec3 rhs)
    {
        return x * rhs.x + y * rhs.y + z * rhs.z; 
    }

    // Returns length of vector
    public final float length()
    {
        return (float)Math.sqrt(x * x + y * y + z * z);
    }

    // Returns squared length of vector
    public final float lengthSquared()
    {
        return x * x + y * y + z * z;
    }

    // Normalizes this vector
    public final Vec3 normalize()
    {
        float l = x * x + y * y + z * z; 
        if (l != 0.0)
        {
            l = 1 / (float)Math.sqrt(l);
            x *= l;
            y *= l;
            z *= l;
        }
        return this;
    }

    // Sets this vector to be the result of 3-D transformation of itself
    // by given matrix (m).
    //
    // This transformation only takes upper 3x3 submatrix of matrix (m)
    // into an account (w coordinate of vector is assumed to be zero).
    // 
    // v' = vM  
    public final void transform(final Matrix m)
    {
        final float tx = x * m.m00 + y * m.m10 + z * m.m20;
        final float ty = x * m.m01 + y * m.m11 + z * m.m21;
        z = x * m.m02 + y * m.m12 + z * m.m22;
        x = tx;
        y = ty;
    }

    // Sets this vector to be the result of 3-D vector transformation of
    // given vector (v) by given matrix (m).
    // This transformation only takes upper 3x3 submatrix of matrix (m)
    // into an account (w coordinate of vector is assumed to be zero).
    // 
    // v' = vM  
    public final void transform(final Vec3 v, final Matrix m)
    {
        x = v.x * m.m00 + v.y * m.m10 + v.z * m.m20;
        y = v.x * m.m01 + v.y * m.m11 + v.z * m.m21;
        z = v.x * m.m02 + v.y * m.m12 + v.z * m.m22;
    }

    // Sets this vector to be the result of 3-D transformation of itself
    // by given matrix (m).
    // This transformation performs rotation/scaling + translation.
    //
    // v' = [vx vy vz 1] * M
    public final void transformPoint(final Matrix m)
    {
        final float tx = x * m.m00 + y * m.m10 + z * m.m20 + m.m30;
        final float ty = x * m.m01 + y * m.m11 + z * m.m21 + m.m31;
        z = x * m.m02 + y * m.m12 + z * m.m22 + m.m32;
        x = tx;
        y = ty;
    }

    // Sets this vector to be the result of 3-D transformation of given
    // point (v) by given matrix (m).
    // This transformation performs rotation/scaling + translation.
    //
    // v' = [vx vy vz 1] * M
    public final void transformPoint(final Vec3 v, final Matrix m)
    {
        x = v.x * m.m00 + v.y * m.m10 + v.z * m.m20 + m.m30;
        y = v.x * m.m01 + v.y * m.m11 + v.z * m.m21 + m.m31;
        z = v.x * m.m02 + v.y * m.m12 + v.z * m.m22 + m.m32;
    }

    public final String toString()
    {
        return "[" + x + "\t" + y + "\t" + z + "]";
    }

    //-------------------------------------------------------------------------
    // Member variables
    //-------------------------------------------------------------------------

    public float x;
    public float y;
    public float z;
}
//-----------------------------------------------------------------------------
