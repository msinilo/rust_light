//=============================================================================
// Class:       Camera
//=============================================================================
public final class Camera
{
    public void getToWorldMatrix(Matrix m)
    {
        m.set(m_mtxToWorld);
    }

    public void setToWorldMatrix(final Matrix m)
    {
        m_mtxToWorld.set(m);
    }

    public void setFOV(final float fov)
    {
        m_fov = fov;
        m_bRecalcProjMtx = true;        
    }
    
    public float getFOV()
    {
        return m_fov;
    }

    public void setAspect(final float aspect)
    {
        m_aspect = aspect;
        m_bRecalcProjMtx = true;        
    }

    public float getAspect()
    {
        return m_aspect;
    }

    public void setNearFar(final float n, final float f)
    {
        m_zNear = n;
        m_zFar = f;
        m_bRecalcProjMtx = true;
    }

    public void getNearFar(float[] nf)
    {
        nf[0] = m_zNear;
        nf[1] = m_zFar;
    }

    public void getProjectionMatrix(Matrix m)
    {
        if (m_bRecalcProjMtx)
        {
                m_mtxProj.setProjection(m_fov, m_aspect, m_zNear, m_zFar);
                m_bRecalcProjMtx = false;
        }

        m.set(m_mtxProj);
    }

    private float   m_zNear = 1.0f;
    private float   m_zFar = 5000.0f;
    private float   m_aspect = 1.0f;    // Height/width aspect
    private float   m_fov = 90.0f;      // Horizontal FOV (angular)
    private Matrix  m_mtxToWorld = new Matrix(Matrix.IDENTITY);
    private Matrix  m_mtxProj = new Matrix(Matrix.IDENTITY);
    private boolean m_bRecalcProjMtx = true;
}
//-----------------------------------------------------------------------------
