//=============================================================================
// Class:       VecMath
//
// Desc:        Misc constants/methods connected with vector maths (well,
//              not only).
//=============================================================================
public final class VecMath
{
	//-------------------------------------------------------------------------
	// Constants
	//-------------------------------------------------------------------------

	public static final float EPSILON 	= 1e-4f;
	public static final float SMALL_EPSILON = 1e-8f;
	public static final float PI 		= 3.14159265358979324f;
	public static final float TWO_PI 	= 6.28318530717958648f;
	public static final float HALF_PI 	= 1.57079632679489662f;
	public static final float INFINITY 	= 99999999999.0f; // !!!!!!

    // Converts degrees to radians
    public static final float degsToRads(float fDegs)
    {
        return fDegs * PI / 180.0f;
    }

    // Converts radians to degrees
    public static final float radsToDegs(float fRads)
    {
        return fRads * 180.0f / PI;
    }

    // Returns absolute value of a
    public static final float abs(float a)	{ return a > 0 ? a : -a; }

    // By D. Eberly - fast acos
    public static final float acos(float x)
    {
        if (x >= -1.0f)
        {
            if (x < 1.0f)
                return (float)java.lang.Math.acos(x);
            else
                return 0.0f;
        }
        else
        {
            return PI;
        }
    }

    // Returns square of x
    public static final float sqr(float x)
	{
		return x * x;
	}

    // Return sign of given value.
    // (-1 if 'fVal' < 0, 0 if == 0 and +1 if > 0)
    public static final int sign(float fVal)
    {
        return (fVal > 0 ? 1 : (fVal < 0 ? -1 : 0));
    }

    // Out: Random number in [0, 1) range
    public static final float unitRandom()
    {
        return (float)java.lang.Math.random();
    }

	// Comparison with tolerance level
	//
	// Out:		+1 if x > y
	//		    00 if x == y
	//		    -1 if x < y
	public static final int tolCmp(float x, float y, float tol)
	{
        if (x + tol < y)
            return -1;
        else if (y + tol < x)
            return 1;
        else
            return 0;
	}

	// Clamp
	public static final int clamp(int n, int min, int max)
	{
		return (n < min ? min : (n > max ? max : n));
	}

	public static final float clamp(float n, float min, float max)
	{
		return (n < min ? min : (n > max ? max : n));
	}

	public static final int max(int n, int maxx)
	{
		return (n > maxx ? maxx : n);
	}

	public static final int min(int n, int minn)
	{
		return (n < minn ? minn : n);
	}

	public static final float max(float n, float maxx)
	{
		return (n > maxx ? maxx : n);
	}

	public static final float min(float n, float minn)
	{
		return (n < minn ? minn : n);
	}
}
//-----------------------------------------------------------------------------
